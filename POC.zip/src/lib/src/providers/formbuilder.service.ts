import { Injectable } from '@angular/core';
import { FormGroup, Validators, FormBuilder, FormArray, FormControl } from '@angular/forms';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable()
export class FormBuilderService {

    form: any;
    errors: any;
    messages: any;
    formArrayName: string;
    constructor(private formBuilder: FormBuilder) {
    }

    buildForm(formConfig) {
        const formObj = {};
        const formErrorsObj = {};
        for (const itrFieldConfig of formConfig) {
            const validationArray = [];
            if (itrFieldConfig.validation.required) {
                if (itrFieldConfig.elementType === 'checkbox') {
                    validationArray.push(Validators.requiredTrue);
                } else if (itrFieldConfig.customValidation) {
                    validationArray.push(itrFieldConfig.customValidation);
                } else {
                    validationArray.push(Validators.required);
                }
            }
            if (itrFieldConfig.validation.pattern) {
                validationArray.push(Validators.pattern(itrFieldConfig.validation.pattern));
            }
            formObj[itrFieldConfig.formControlName] = [itrFieldConfig.initialValue, validationArray];
            formErrorsObj[itrFieldConfig.formControlName] = '';
        }
        const formErrors = formErrorsObj;
        const validationMessages = this.createValidationMessageObj(formConfig);
        const appForm = this.formBuilder.group(formObj);
        this.validate(
            appForm,
            formErrors,
            validationMessages);

        return { form: appForm, errors: formErrors };
    }

    private createValidationMessageObj(formConfig) {
        const validationMessagesObj = {};
        for (const itrFormCongig of formConfig) {
            validationMessagesObj[itrFormCongig.formControlName] = itrFormCongig.validation.errorMessages;
        }
        return validationMessagesObj;
    }

    validate(form: FormGroup, errors: any, messages: any) {
        this.form = form;
        this.errors = errors;
        this.messages = messages;

        form
            .valueChanges
            .subscribe(data => this.onValueChanged(data));

        this.onValueChanged(); // (re)set validation messages now
    }

    onValueChanged(data?: any) { // helper method
        if (!this.form) { return; }
        const form = this.form;
        for (const field in this.errors) {
            if (field) {
                this.errors[field] = '';  // clear previous error message (if any)
                const control: FormControl = form.get(field);
                if (control && control.dirty && !control.valid) {  // TODO: && control.value.length > 3
                    const messages = this.messages[field];
                    for (const key in control.errors) {
                        if (key) {
                            this.errors[field] += messages[key] + ' ';
                            // this.translateService.get(messages[key]).subscribe((res: string) => {
                            // });
                        }
                    }
                }
            }
        }
    }
}