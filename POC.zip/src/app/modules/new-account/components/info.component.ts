import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder, FormArray, FormControl } from '@angular/forms';
import { FORMCONFIG, STATEOPTS } from './formconfig';
import { FormBuilderService } from './../../../../lib/src/providers/formbuilder.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-info',
  templateUrl: './info.component.html',
  providers: [FormBuilderService]
//  styleUrls: ['./info.component.scss']
})
export class InfoComponent implements OnInit {
 
  title = 'Form works!';
  form1: any;
  formConfig: any;
  formErrors: any;
  form2: any;
  formErrors2: any;

  stateOptions: any;

  constructor(private formBuilderService: FormBuilderService, private router: Router) {

  }

  ngOnInit() {
    this.formConfig = FORMCONFIG.fields;
    const formbuild = this.formBuilderService.buildForm(this.formConfig);
    this.formErrors = formbuild.errors;
    this.form1 = formbuild.form;
    this.form1.valueChanges.subscribe(data => {
      console.log(this.form1.value, this.form1.valid);
    });

    this.stateOptions = STATEOPTS;
  }
  back() {
    this.router.navigate(['/login']);
  };
  

}
