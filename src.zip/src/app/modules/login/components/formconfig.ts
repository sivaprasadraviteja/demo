export const FORMCONFIG = {
    fields: [
        {
            elementType: 'input',
            formControlName: 'Username',
            initialValue: '',
            validation: {
                required: true,
                errorMessages: {
                    required: 'Please provide Username',
                    minlength:'Username should be minimum of five characters'
                }
            }
        },
        {
            elementType: 'input',
            formControlName: 'Password',
            initialValue: '',
            validation: {
                required: true,
                errorMessages: {
                    required: 'Please provide Password',
                    minlength:'Password should be minimum of five characters'
                }
            }
        },
    ]
};