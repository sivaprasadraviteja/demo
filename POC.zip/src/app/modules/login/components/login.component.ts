import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder, FormArray, FormControl } from '@angular/forms';
import { FORMCONFIG} from './formconfig';
import { FormBuilderService } from './../../../../lib/src/providers/formbuilder.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [FormBuilderService]
})
export class LoginComponent implements OnInit {
  title = 'Form works!';
  form1: any;
  formConfig: any;
  formErrors : any;
  valid:boolean = true;
  
  constructor(private formBuilderService: FormBuilderService,private router: Router) { }

  ngOnInit() {
    this.formConfig = FORMCONFIG.fields;
    const formbuild = this.formBuilderService.buildForm(this.formConfig);
    this.formErrors = formbuild.errors;
    this.form1 = formbuild.form;
    //this.valid = true;
    this.form1.valueChanges.subscribe(data => {
     console.log(this.form1.value, this.form1.valid);
    });
    
  }
  login() {
    
    if (this.form1.controls['Username'].value == 'admin' &&  this.form1.controls['Password'].value == 'admin') {
      console.log("inside");
      this.router.navigate(['/newAccount']);
      } else {
        console.log('nomatch');
        
      }
  };
  eventHandler() {
    this.valid = false;
 } 
}
