import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InfoComponent } from './components/info.component'

const routes: Routes = [

{path: '', component: InfoComponent}

];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);