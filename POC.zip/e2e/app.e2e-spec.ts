import { CitiPage } from './app.po';

describe('citi App', () => {
  let page: CitiPage;

  beforeEach(() => {
    page = new CitiPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
