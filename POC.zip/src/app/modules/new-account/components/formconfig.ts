export const FORMCONFIG = {
    fields: [
        {
            elementType: 'input',
            formControlName: 'businessname',
            initialValue: '',
            validation: {
                required: true,
                errorMessages: {
                    required: 'Please provide details'
                    
                }
            }
        },
        {
            elementType: 'input',
            formControlName: 'taxID',
            initialValue: '',
            validation: {
                required: true,
                errorMessages: {
                    required: 'Please provide details'
                }
            }
        },
        {
            elementType: 'input',
            formControlName: 'contactname',
            initialValue: '',
            validation: {
                required: true,
                errorMessages: {
                    required: 'Please provide details'
                }
            }
        },
        {
            elementType: 'input',
            formControlName: 'phonenumber',
            initialValue: '',
            validation: {
                required: true,
                errorMessages: {
                    required: 'Please provide details',
                    pattern:'Please provide a valid number'
                }
            }
        },
         {
            elementType: 'input',
            formControlName: 'ACHname',
            initialValue: '',
            validation: {
                required: true,
                errorMessages: {
                    required: 'Please provide details'
                }
            }
        },
         {
            elementType: 'input',
            formControlName: 'streetnumber',
            initialValue: '',
            validation: {
                required: true,
                errorMessages: {
                    required: 'Please provide details'
                }
            }
        },
         {
            elementType: 'input',
            formControlName: 'streetname',
            initialValue: '',
            validation: {
                required: true,
                errorMessages: {
                    required: 'Please provide details'
                }
            }
        },
         {
            elementType: 'input',
            formControlName: 'city',
            initialValue: '',
            validation: {
                required: true,
                errorMessages: {
                    required: 'Please provide details'
                }
            }
        },               
        {
            elementType: 'dropdown',
            formControlName: 'state',
            initialValue: '',
            validation: {
                required: true,
                errorMessages: {
                    required: 'State mandatory'
                }
            }
        },
        {
            elementType: 'input',
            formControlName: 'zip',
            initialValue: '',
            validation: {
                required: true,
                errorMessages: {
                    required: 'Please provide details',
                    pattern:'Please provide a valid number'
                }
            }
        },     
    
    ]
};

export const STATEOPTS = [
     { key: 'NY', label: 'New York' },
     { key: 'NJ', label: 'New Jersey' },
     { key: 'CA', label: 'California' },
     { key: 'DL', label: 'Delaware' },
     { key: 'TX', label: 'Texas' },
     { key: 'FL', label: 'Florida' }
];

                
               
            


