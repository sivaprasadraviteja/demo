import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';

export const appRoutes: Routes = [
{ path: 'newAccount', loadChildren:'./modules/new-account/new-account.module#NewAccountModule'},
{ path: 'login', loadChildren:'./modules/login/login.module#LoginModule'},
{ path: '', loadChildren:'./modules/login/login.module#LoginModule'},
{ path: '**', redirectTo: '/login' } 
];

export const appRoutingProviders: any[] = [

];

export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes, {
   preloadingStrategy: PreloadAllModules
});