import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {RouterModule} from '@angular/router';

import { routing } from './login.routing';
import { LoginComponent } from './components/login.component'

@NgModule({
  
    imports: [
      CommonModule,
      routing,
      FormsModule,
      ReactiveFormsModule,
      RouterModule
    ],
    declarations: [
      LoginComponent
    ]
  })
export class LoginModule { }
