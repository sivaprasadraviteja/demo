import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { routing } from './new-account.routing';
import { InfoComponent } from './components/info.component'

@NgModule({

	imports: [
		CommonModule,
		routing,
		FormsModule,
		ReactiveFormsModule
	],
	declarations: [
		InfoComponent
	]
})
export class NewAccountModule {}

